JET Queued State Machine Toolkit
Release 0

Copyright (c) 2010 JET Engineering, Inc.
See License Agreement file for license information.

This toolkit provides the basic framework to create queued state machine (QSM)
architectures with LabVIEW. It was developed with LabVIEW version 2009 SP1.

Features:

Fast - All operations are order O(1) relative to the size of the queue. This
       means that as more states are enqueued, QSM speed does not suffer.

Efficient - QSM speed and resource usage is not affected by queue contents.

Flexible - String based states

Debugging - User configurable debug mode with previous states and timestamps

Conditional Add - boolean input to Add State(s) functions is available

Data and Comment can be added to each state

Multiple state add is easy


VIs In the Toolkit:
Initialize
 This VI sets up the properties for the queued state machine and returns a refnum. 
 Inputs are provided for default states in event of idle, error, stop and 
 initialize. This VI will also enqueue the initialize state upon execution.

Add States [Strings]
 Adds (enqueues) states to the QSM. If state(s) input is empty, this VI does 
 nothing. Multiple states can be enqueued by separating them with a line feed.
 State data and state comment will be added to all states enqueued.

Add States [Arrays]
 Adds (enqueues) states to the QSM. If State Array input is empty, this VI does 
 nothing. Multiple states can be enqueued by adding them as elements to the State 
 Array input. Data Array and Comment Array inputs are parallel to the State Array. 
 Any elements in these arrays beyond the size of the State Array will be ignored.

Add States to Front [Strings]
 Adds (enqueues) states to the QSM. If state(s) input is empty, this VI does nothing. 
 Multiple states can be enqueued by separating them with a line feed. State data and 
 state comment will be added to all states enqueued.

Add States to Front [Arrays]
 Adds (enqueues) states to the QSM. If State Array input is empty, this VI does nothing. 
 Multiple states can be enqueued by adding them as elements to the State Array input. 
 Data Array and Comment Array inputs are parallel to the State Array. Any elements in 
 these arrays beyond the size of the State Array will be ignored.

Add Stop
 Enqueues the stop state.

Get Next State
 Returns the next state from the queue. If no states are enqueued, the idle state is 
 returned. If the error input is true, this VI returns the error state. If debugging is 
 enabled on the QSM, the state and timestamp are also added to the debug queue.

Flush
 Removes all pending states from the queue and returns the number of states flushed 
 from the queue.

---Debug VIs---
Flush Devbug Queue
 Removes all states from the debug queue and returns those state names.

Set Debug Options
 Sets the debug options for the QSM refnum.